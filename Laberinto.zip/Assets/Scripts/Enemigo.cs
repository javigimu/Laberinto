using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Enemigo : MonoBehaviour
{
    [SerializeField] Transform[] wayPoints;
    private float velocidad = 1;
    private Vector3 siguientePosicion;
    private int numeroSiguientePosicion = 0;
    private float distanciaCambio = 0.2f;


    // Start is called before the first frame update
    void Start()
    {
        siguientePosicion = wayPoints[0].position;
    }

    // Update is called once per frame
    void Update()
    {
        MoverHaciaWaypoints();
    }

    private void MoverHaciaWaypoints()
    {
        transform.position = Vector3.MoveTowards(transform.position,
            siguientePosicion, velocidad * Time.deltaTime);

        if (Vector3.Distance(
            transform.position, siguientePosicion) < distanciaCambio)
        {
            numeroSiguientePosicion++;
            if (numeroSiguientePosicion >= wayPoints.Length)
                numeroSiguientePosicion = 0;

            siguientePosicion = wayPoints[numeroSiguientePosicion].position;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Personaje")
            other.SendMessage("PerderVida");
    }

    private void IncrementarVelocidad(float aumentoVelocidad)
    {
        velocidad += aumentoVelocidad;
    }
}
