using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;
using UnityEngine.UIElements;

public class Personaje : MonoBehaviour
{
    private Rigidbody body;
    private float velAvance = 5f;
    private float velRotacion = 120f;

    private float xInicial;
    private float zInicial;
    private int vidas = 3;

    // para que el personaje mire en la direcci�n inicial al volver al principio
    private Quaternion rotacionInicial; 


    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody>();
        xInicial = transform.position.x;
        zInicial = transform.position.z;

        rotacionInicial = transform.rotation;
    }

    // Update is called once per frame
    void Update()
    {
        Avanzar();
    }

    public void Avanzar()
    {
        float avance = Input.GetAxis("Vertical") * velAvance * Time.deltaTime;
        float rotacion = 
            Input.GetAxis("Horizontal") * velRotacion * Time.deltaTime;        

        transform.Rotate(Vector3.up, rotacion);
        transform.position += transform.forward * avance;        
    }

    public void PerderVida()
    {
        vidas--;

        if (vidas <= 0)
        {
            Debug.Log("Partida terminada");
            Application.Quit();
        }
        else
        {
            Debug.Log("Te quedan " + vidas + " vidas");
            Recolocar();
        }
    }

    public void Recolocar()
    {
        transform.position = new Vector3(
                xInicial, transform.position.y, zInicial);
        transform.rotation = rotacionInicial;
    }
}
