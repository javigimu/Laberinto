using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class Personaje : MonoBehaviour
{
    private Rigidbody body;
    private float velAvance = 5f;
    private float velRotacion = 120f;

    private float xInicial;
    private float zInicial;
    private int vidas = 3;

    // para que el personaje mire en la direcci�n inicial al volver al principio
    private Quaternion rotacionInicial;

    [SerializeField] TMP_Text textoGameOver;
    [SerializeField] int nivelActual;
    [SerializeField] int nivelMaximo;
    [SerializeField] TMP_Text textoIntentosNivel;

    private float aumentoVelocidadEnemigos;

    // Start is called before the first frame update
    void Start()
    {
        body = GetComponent<Rigidbody>();
        xInicial = transform.position.x;
        zInicial = transform.position.z;

        rotacionInicial = transform.rotation;
        textoGameOver.enabled = false;

        ActualizarTextoIntentosNivel();
        AumentarVelocidadEnemigos();       
    }       

    // Update is called once per frame
    void Update()
    {
        Avanzar();
    }

    private void Avanzar()
    {
        float avance = Input.GetAxis("Vertical") * velAvance * Time.deltaTime;
        float rotacion = 
            Input.GetAxis("Horizontal") * velRotacion * Time.deltaTime;        

        transform.Rotate(Vector3.up, rotacion);
        transform.position += transform.forward * avance;        
    }

    private void PerderVida()
    {
        vidas--;

        if (vidas <= 0)
        {
            StartCoroutine(TerminarPartida("GAME OVER"));
        }
        else
        {
            ActualizarTextoIntentosNivel();
            Recolocar();
        }
    }

    private IEnumerator TerminarPartida(string textoFin)
    {
        textoGameOver.text = textoFin;
        textoGameOver.color = Color.red;
        textoGameOver.enabled = true;
        ReiniciarVidas();

        // Ralentizo el juego, espero 5 segundos y lanzo la bienvenida
        Time.timeScale = 0.1f;
        yield return new WaitForSecondsRealtime(5);
        Time.timeScale = 1;
        SceneManager.LoadScene("Bienvenida");
    }

    private void ReiniciarVidas()
    {
        vidas = 3;
    }

    private void Recolocar()
    {
        transform.position = new Vector3(
                xInicial, transform.position.y, zInicial);
        transform.rotation = rotacionInicial;
    }

    private void ActualizarTextoIntentosNivel()
    {
        textoIntentosNivel.text = "Nivel " + nivelActual + Environment.NewLine
            + "Intentos " + vidas;
    }

    private void SubirDeNivel()
    {
        nivelActual++;
        if (nivelActual > nivelMaximo)
        {
            StartCoroutine(TerminarPartida("FIN"));
        }
        else
        {
            SceneManager.LoadScene("Nivel" + nivelActual);
        }
    }

    private void AumentarVelocidadEnemigos()
    {
        aumentoVelocidadEnemigos = nivelActual * 1.2f;

        foreach (Enemigo enemigo in FindObjectsOfType<Enemigo>())
            enemigo.SendMessage("IncrementarVelocidad", aumentoVelocidadEnemigos);
    }
}
